package com.example.mycrud.models

data class EmployeeModel(
    var empId: String? = null,
    var empCourseName: String? = null,
    var empDuration: String? = null,
    var empDonatePrice: String? = null
)